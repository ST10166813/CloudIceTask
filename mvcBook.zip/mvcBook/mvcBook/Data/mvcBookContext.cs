﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using mvcBook.Models;

namespace mvcBook.Data
{
    public class mvcBookContext : DbContext
    {
        public mvcBookContext (DbContextOptions<mvcBookContext> options)
            : base(options)
        {
        }

        public DbSet<mvcBook.Models.Books> Books { get; set; } = default!;
    }
}
